# Format of pixel_pos.csv file for each dataset

Size of the matrix is 4 x numTrajectoryPoints

The first row contains all the frame numbers

The second row contains all the pedestrian IDs

The third row contains all the y-coordinates

The fourth row contains all the x-coordinates
